package bless.datediary.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ScheduleRequest {
    String id;
    String password;


}
